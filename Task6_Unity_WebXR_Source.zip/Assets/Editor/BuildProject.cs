using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using UnityEditor.XR.Management;
using UnityEditor.XR.Management.Metadata;
using UnityEngine.XR.Management;
using WebXR;
using System.IO;
public static class BuildProject {
 [MenuItem("WebAR/Configure Project")]
 public static void Configure(){
 Directory.CreateDirectory("Assets/XR");
 EditorBuildSettings.TryGetConfigObject<XRGeneralSettingsPerBuildTarget>(XRGeneralSettings.k_SettingsKey,out var targets);
 if(targets==null){targets=ScriptableObject.CreateInstance<XRGeneralSettingsPerBuildTarget>();AssetDatabase.CreateAsset(targets,"Assets/XR/XRGeneralSettings.asset");EditorBuildSettings.AddConfigObject(XRGeneralSettings.k_SettingsKey,targets,true);}
 if(!targets.HasManagerSettingsForBuildTarget(BuildTargetGroup.WebGL))targets.CreateDefaultManagerSettingsForBuildTarget(BuildTargetGroup.WebGL);
 var manager=targets.ManagerSettingsForBuildTarget(BuildTargetGroup.WebGL);
 if(!XRPackageMetadataStore.AssignLoader(manager,"WebXR.WebXRLoader",BuildTargetGroup.WebGL))throw new System.Exception("WebXR loader assignment failed");
 var settings=WebXRSettings.GetSettings();
 if(settings==null){settings=ScriptableObject.CreateInstance<WebXRSettings>();AssetDatabase.CreateAsset(settings,"Assets/XR/WebXRSettings.asset");EditorBuildSettings.AddConfigObject("WebXR.Settings",settings,true);}
 settings.DisableXRDisplaySubsystem=true;settings.AutoLoadWebXRInputSystem=false;settings.ARRequiredReferenceSpace=WebXRSettings.ReferenceSpaceTypes.local;settings.AROptionalFeatures=0;
 EditorUtility.SetDirty(settings);EditorUtility.SetDirty(targets);EditorUtility.SetDirty(manager);
 PlayerSettings.WebGL.compressionFormat=WebGLCompressionFormat.Disabled;PlayerSettings.WebGL.decompressionFallback=false;PlayerSettings.WebGL.threadsSupport=false;PlayerSettings.WebGL.template="PROJECT:WebXR2020";
 PlayerSettings.companyName="treustkey";PlayerSettings.productName="Viewer Space WebAR";
 EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/Scenes/ViewerSpace.unity",true)};
 AssetDatabase.SaveAssets();
 EditorSceneManager.OpenScene("Assets/Scenes/ViewerSpace.unity");
 Debug.Log("WEBAR_CONFIGURATION_OK");
 }
 [MenuItem("WebAR/Create Scene")]
 public static void CreateScene(){
 var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
 var prefab=AssetDatabase.LoadAssetAtPath<GameObject>("Assets/WebXRCameraSet.prefab");
 if(prefab==null)throw new System.Exception("Missing BiRP WebXRCameraSet prefab");
 PrefabUtility.InstantiatePrefab(prefab);
 var cube=GameObject.CreatePrimitive(PrimitiveType.Cube);cube.name="Viewer-space Cube";cube.transform.localScale=Vector3.one*.25f;cube.transform.position=new Vector3(0,0,1.2f);cube.AddComponent<ViewerObject>();
 var material=new Material(Shader.Find("Standard"));material.color=new Color(.2f,.7f,.9f);material.SetFloat("_Metallic",.3f);material.SetFloat("_Glossiness",.6f);AssetDatabase.CreateAsset(material,"Assets/CubeMaterial.mat");cube.GetComponent<Renderer>().sharedMaterial=material;
 var light=new GameObject("Directional Light").AddComponent<Light>();light.type=LightType.Directional;light.transform.rotation=Quaternion.Euler(45,-30,0);RenderSettings.ambientLight=new Color(.45f,.45f,.45f);
 Directory.CreateDirectory("Assets/Scenes");EditorSceneManager.SaveScene(scene,"Assets/Scenes/ViewerSpace.unity");Configure();
 }
 [MenuItem("WebAR/Build WebGL")]
 public static void Build(){
 Configure();
 var report=BuildPipeline.BuildPlayer(new[]{"Assets/Scenes/ViewerSpace.unity"},"docs",BuildTarget.WebGL,BuildOptions.None);
 if(report.summary.result!=BuildResult.Succeeded)throw new System.Exception("WebGL build failed");
 File.WriteAllText("BUILD_SIZE.txt",report.summary.totalSize.ToString()+" bytes");
 Debug.Log("WEBAR_BUILD_OK: "+report.summary.totalSize);
 }
}
