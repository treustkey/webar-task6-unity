using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using System.IO;
using System.Linq;
public static class BuildProject {
 [MenuItem("WebAR/Create Scene")]
 public static void CreateScene(){
 var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
 string prefab=AssetDatabase.FindAssets("WebXRCameraSet t:Prefab").Select(AssetDatabase.GUIDToAssetPath).FirstOrDefault();
 if(prefab==null)throw new System.Exception("Import WebXR Interactions BiRP sample (WebXRCameraSet prefab) first.");
 PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>(prefab));
 var cube=GameObject.CreatePrimitive(PrimitiveType.Cube);cube.name="Viewer-space Cube";cube.transform.localScale=Vector3.one*.25f;cube.AddComponent<ViewerObject>();
 var light=new GameObject("Directional Light").AddComponent<Light>();light.type=LightType.Directional;light.transform.rotation=Quaternion.Euler(45,-30,0);RenderSettings.ambientLight=new Color(.45f,.45f,.45f);
 Directory.CreateDirectory("Assets/Scenes");EditorSceneManager.SaveScene(scene,"Assets/Scenes/ViewerSpace.unity");
 }
 [MenuItem("WebAR/Build WebGL")]
 public static void Build(){
 PlayerSettings.WebGL.compressionFormat=WebGLCompressionFormat.Disabled;
 PlayerSettings.WebGL.decompressionFallback=false;
 PlayerSettings.WebGL.threadsSupport=false;
 PlayerSettings.WebGL.template="PROJECT:WebXR2020";
 PlayerSettings.companyName="treustkey";PlayerSettings.productName="Viewer Space WebAR";
 var report=BuildPipeline.BuildPlayer(new[]{"Assets/Scenes/ViewerSpace.unity"},"docs",BuildTarget.WebGL,BuildOptions.None);
 if(report.summary.result!=BuildResult.Succeeded)throw new System.Exception("WebGL build failed");
 File.WriteAllText("BUILD_SIZE.txt",report.summary.totalSize.ToString()+" bytes");
 }
}

