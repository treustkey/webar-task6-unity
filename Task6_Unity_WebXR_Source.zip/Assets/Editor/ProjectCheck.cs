using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using WebXR;
using System.IO;
public static class ProjectCheck {
 public static void Validate(){
 var scene=EditorSceneManager.OpenScene("Assets/Scenes/ViewerSpace.unity");
 int missing=0;foreach(var root in scene.GetRootGameObjects())foreach(var transform in root.GetComponentsInChildren<Transform>(true))missing+=GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(transform.gameObject);
 if(missing!=0)throw new System.Exception("Missing scripts: "+missing);
 var cube=GameObject.Find("Viewer-space Cube");if(cube==null||cube.GetComponent<ViewerObject>()==null)throw new System.Exception("Viewer object missing");
 var cameras=Object.FindObjectsByType<Camera>(FindObjectsInactive.Include,FindObjectsSortMode.None);
 var controllers=Object.FindObjectsByType<WebXRController>(FindObjectsInactive.Include,FindObjectsSortMode.None);
 if(cameras.Length<5||controllers.Length<2)throw new System.Exception("WebXR camera rig incomplete");
 var settings=WebXRSettings.GetSettings();if(settings==null||!settings.DisableXRDisplaySubsystem)throw new System.Exception("BiRP settings missing");
 var summary="SCENE_VALIDATED: cameras="+cameras.Length+", controllers="+controllers.Length+", missingScripts="+missing;
 File.WriteAllText("VALIDATION.txt",summary);Debug.Log(summary);
 }
}
