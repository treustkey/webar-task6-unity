using UnityEngine;
public class ViewerObject : MonoBehaviour {
 public float distance = 1.2f;
 void LateUpdate() { var camera=Camera.main; if(camera==null)return; transform.position=camera.transform.position+camera.transform.forward*distance; transform.rotation=camera.transform.rotation*Quaternion.Euler(15,30,0); }
}
