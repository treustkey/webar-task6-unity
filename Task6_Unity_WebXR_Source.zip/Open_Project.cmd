@echo off
set BEE_BUILD_THREADS=8
start "" "C:\Program Files\Unity\Hub\Editor\6000.3.7f1\Editor\Unity.exe" -projectPath "C:\Users\user\Documents\Task6_Unity_WebXR"
